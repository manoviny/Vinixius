# tcnotuchtuch
Estudo de JavaScript.
